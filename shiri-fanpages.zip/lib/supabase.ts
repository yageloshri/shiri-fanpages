import { createClient } from '@supabase/supabase-js'

export const supabase = createClient(
  "https://kqirlwylvuawqkxwdsxj.supabase.co",
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtxaXJsd3lsdnVhd3FreHdkc3hqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDY5NzA3NzcsImV4cCI6MjA2MjU0Njc3N30.5vbX49Lqv4Wgwv3hwdgiwhK4LtzUxzJA5M3v7dGTXk0"
)